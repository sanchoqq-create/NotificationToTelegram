package ru.example.notificationtotelegram

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.os.Bundle
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class ForwarderService : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val allowed = prefs.getStringSet("selected_apps", emptySet()) ?: emptySet()
        if (sbn.packageName !in allowed) return

        val token = prefs.getString("token", "")?.trim().orEmpty()
        val chatId = prefs.getString("chat_id", "")?.trim().orEmpty()
        if (token.isBlank() || chatId.isBlank()) return

        val n = sbn.notification ?: return
        val extras: Bundle = n.extras ?: Bundle.EMPTY
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString().orEmpty()

        if (title.isBlank() && text.isBlank()) return

        val appName = try {
            val app = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(app).toString()
        } catch (_: Exception) { sbn.packageName }

        val time = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date(sbn.postTime))
        val message = buildString {
            append("📲 ").append(appName).append('\n')
            if (title.isNotBlank()) append("Отправитель: ").append(title).append('\n')
            if (text.isNotBlank()) append(text).append('\n')
            append("Время: ").append(time)
        }

        executor.execute { sendTelegram(token, chatId, message) }
    }

    private fun sendTelegram(token: String, chatId: String, message: String) {
        var connection: HttpURLConnection? = null
        try {
            val url = URL("https://api.telegram.org/bot$token/sendMessage")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            }
            val body = "chat_id=${enc(chatId)}&text=${enc(message)}&disable_web_page_preview=true"
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            connection.inputStream.close()
        } catch (_: Exception) {
            // Ошибка сети не должна останавливать NotificationListenerService.
        } finally {
            connection?.disconnect()
        }
    }

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
}
