package ru.example.notificationtotelegram

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.os.Bundle
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class ForwarderService : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onListenerConnected() {
        super.onListenerConnected()
        Diagnostics.log(this, "Служба подключена")
    }
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Diagnostics.log(this, "Служба отключена")
        requestRebind(android.content.ComponentName(this, ForwarderService::class.java))
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val allowed = prefs.getStringSet("selected_apps", emptySet()) ?: emptySet()
        if (sbn.packageName !in allowed) return
        Diagnostics.log(this, "Получено уведомление: ${sbn.packageName}")

        val token = prefs.getString("token", "")?.trim().orEmpty()
        val chatId = prefs.getString("chat_id", "")?.trim().orEmpty()
        if (token.isBlank() || chatId.isBlank()) { Diagnostics.log(this, "Не заполнены настройки Telegram"); return }

        val n = sbn.notification ?: return
        val extras: Bundle = n.extras ?: Bundle.EMPTY
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString().orEmpty()

        if (title.isBlank() && text.isBlank()) { Diagnostics.log(this, "Пустое содержимое уведомления"); return }

        val appName = try {
            val app = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(app).toString()
        } catch (_: Exception) { sbn.packageName }

        val time = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date(sbn.postTime))
        val message = buildString {
            append("📲 ").append(appName).append('\n')
            if (title.isNotBlank()) append("Отправитель: ").append(title).append('\n')
            if (text.isNotBlank()) append(text).append('\n')
            append("Время: ").append(time)
        }

        executor.execute { Diagnostics.send(this, token, chatId, message) }
    }

}
