package ru.example.notificationtotelegram

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var token: EditText
    private lateinit var chatId: EditText
    private lateinit var appsBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var journal: TextView
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            val manager = getSystemService(android.app.NotificationManager::class.java)
            val enabled = manager.isNotificationListenerAccessGranted(android.content.ComponentName(this@MainActivity, ForwarderService::class.java))
            status.text = if (enabled) "Доступ к уведомлениям: разрешён" else "Доступ к уведомлениям: НЕ разрешён"
            journal.text = getSharedPreferences("diagnostics", MODE_PRIVATE).getString("log", "Журнал пока пуст")
            handler.postDelayed(this, 1000)
        }
    }
    override fun onResume() { super.onResume(); handler.post(refresh) }
    override fun onPause() { handler.removeCallbacks(refresh); super.onPause() }
    private val selected = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected.addAll(prefs.getStringSet("selected_apps", emptySet()) ?: emptySet())

        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }
        scroll.setBackgroundColor(android.graphics.Color.parseColor("#121212"))
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout())
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        }
        scroll.addView(layout)
        setContentView(scroll)

        layout.addView(TextView(this).apply {
            text = "Пересылка уведомлений в Telegram"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        })
        layout.addView(label("Токен Telegram-бота"))
        token = EditText(this).apply {
            hint = "123456:ABC..."
            singleLine = true
            inputType =  visiblePasswordInput()
            setText(prefs.getString("token", ""))
        }
        layout.addView(token)
        layout.addView(label("Chat ID"))
        chatId = EditText(this).apply {
            hint = "Например, 123456789"
            singleLine = true
            setText(prefs.getString("chat_id", ""))
        }
        layout.addView(chatId)

        val save = Button(this).apply { text = "Сохранить настройки Telegram" }
        save.setOnClickListener {
            prefs.edit().putString("token", token.text.toString().trim())
                .putString("chat_id", chatId.text.toString().trim()).apply()
            Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
        }
        layout.addView(save)

        val permission = Button(this).apply { text = "Разрешить доступ к уведомлениям" }
        permission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        layout.addView(permission)
        status = TextView(this)
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Переподключить службу"
            setOnClickListener {
                android.service.notification.NotificationListenerService.requestRebind(android.content.ComponentName(this@MainActivity, ForwarderService::class.java))
                Diagnostics.log(this@MainActivity, "Запрошено переподключение")
            }
        })
        layout.addView(Button(this).apply {
            text = "Отправить тест в Telegram"
            setOnClickListener {
                val t = token.text.toString().trim()
                val c = chatId.text.toString().trim()
                prefs.edit().putString("token", t).putString("chat_id", c).apply()
                Thread { Diagnostics.send(applicationContext, t, c, "Тест NotificationToTelegram 1.2") }.start()
            }
        })
        layout.addView(Button(this).apply {
            text = "Настройки фоновой работы"
            setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        })
        layout.addView(label("Журнал диагностики"))
        journal = TextView(this).apply { setTextIsSelectable(true); textSize = 12f; maxLines = 12 }
        layout.addView(journal)
        layout.addView(Button(this).apply {
            text = "Очистить журнал"
            setOnClickListener { getSharedPreferences("diagnostics", MODE_PRIVATE).edit().clear().apply() }
        })

        layout.addView(label("Пересылать уведомления этих приложений"))
        layout.addView(TextView(this).apply {
            text = "Отметь нужные приложения. Само приложение-пересыльщик исключено."
            textSize = 13f
        })
        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        layout.addView(appsBox)
        loadApps()

        val saveApps = Button(this).apply { text = "Сохранить выбранные приложения" }
        saveApps.setOnClickListener {
            prefs.edit().putStringSet("selected_apps", selected.toSet()).apply()
            Toast.makeText(this, "Список приложений сохранён", Toast.LENGTH_SHORT).show()
        }
        layout.addView(saveApps)

        layout.addView(TextView(this).apply {
            text = "Важно: Android должен иметь разрешение на доступ к уведомлениям. Некоторые приложения скрывают содержимое уведомлений, поэтому их текст может быть недоступен."
            textSize = 12f
        })
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 24, 0, 8)
    }

    private fun visiblePasswordInput(): Int =
        android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

    private fun loadApps() {
        appsBox.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != packageName }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }

        for (app in apps) {
            val cb = CheckBox(this).apply {
                text = packageManager.getApplicationLabel(app)
                isChecked = selected.contains(app.packageName)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(app.packageName) else selected.remove(app.packageName)
                    prefs.edit().putStringSet("selected_apps", selected.toSet()).apply()
                }
            }
            appsBox.addView(cb)
        }
    }
}
