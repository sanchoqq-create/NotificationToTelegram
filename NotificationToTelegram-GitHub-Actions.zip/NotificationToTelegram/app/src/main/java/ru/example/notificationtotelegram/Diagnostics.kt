package ru.example.notificationtotelegram

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

object Diagnostics {
    @Synchronized fun log(context: Context, message: String) {
        val p = context.getSharedPreferences("diagnostics", Context.MODE_PRIVATE)
        val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        p.edit().putString("log", ("$time $message\n" + p.getString("log", "").orEmpty()).take(16000)).apply()
    }
    fun send(context: Context, token: String, chatId: String, message: String) {
        if (token.isBlank() || chatId.isBlank()) { log(context, "Заполните токен и Chat ID"); return }
        for (attempt in 1..2) {
            var c: HttpURLConnection? = null
            try {
                val conn = URL("https://api.telegram.org/bot$token/sendMessage").openConnection() as HttpURLConnection
                c = conn
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.doOutput = true
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                val body = "chat_id=${enc(chatId)}&text=${enc(message.take(4000))}"
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val response = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val ok = runCatching { JSONObject(response).optBoolean("ok") }.getOrDefault(false)
                log(context, if (ok) "Telegram: отправлено" else "Telegram: HTTP $code, отправка не подтверждена")
                if (ok || code !in 500..599) return
            } catch (e: Exception) {
                log(context, "Ошибка сети: ${e.javaClass.simpleName}, попытка $attempt")
            } finally { c?.disconnect() }
            if (attempt == 1) try { Thread.sleep(2000) } catch (_: InterruptedException) { return }
        }
    }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
