plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ru.example.notificationtotelegram"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.example.notificationtotelegram"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
    kotlinOptions { jvmTarget = "17" }
}
